import sys

from mox3 import mox

sys.modules['mox'] = mox
