==========
oslo.utils
==========

.. image:: https://img.shields.io/pypi/v/oslo.utils.svg
    :target: https://pypi.python.org/pypi/oslo.utils/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/dm/oslo.utils.svg
    :target: https://pypi.python.org/pypi/oslo.utils/
    :alt: Downloads

The oslo.utils library provides support for common utility type functions,
such as encoding, exception handling, string manipulation, and time handling.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/oslo.utils
* Source: http://git.openstack.org/cgit/openstack/oslo.utils
* Bugs: http://bugs.launchpad.net/oslo.utils



